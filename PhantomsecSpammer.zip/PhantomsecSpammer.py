import time, sys, pyautogui, os, colorama
from colorama import Fore, Style
print(Fore.BLUE + "Phantomsec Spammer")

def Quit():
    print("Thank you for using Phantomsec Spammer.")
    time.sleep(2)
    sys.exit()
def restart_program():
    python = sys.executable
    os.execl(python, python, * sys.argv)
    curdir = os.getcwd()
def spam1():
        f = open("bee", 'r')
        for word in f:
            pyautogui.typewrite(word)
            pyautogui.press("enter")
            time.sleep(1)

def spam2():
        g = open("fuckyou", 'r')
        for word in g:
                pyautogui.typewrite(word)
                pyautogui.press("enter")
                time.sleep(1)

def spam3():
       h = open("hulksmash", 'r')
       for word in h:
               pyautogui.typewrite(word)
               pyautogui.press("enter")
               time.sleep(1)

def spam4():
    l = open("phantomsecrules", 'r')
    for word in l:
        pyautogui.typewrite(word)
        pyautogui.press("enter")
        time.sleep(1)


def Credits():
        print ("Made By anoncfw")
        restart_program()


def menu():
        print ("*****Choices*****")
time.sleep(1)


choice= input("""   
                    A. Bee movie script
                    B. fuck you                                     
                    C. hulk smash
                    D. Phantomsec rules                                   
                    E. Credits 
                    F. Quit                                        
                    
                    Please choose A B C or D   
                    Made by anoncfw 
                    Phantomsec, a grey hat hacking group
                    We are ther when you need us 
                    we are there when you dont expect us
                    expect us
                    we are there when the world needs us
                    We are Phantomsec
    """)
print ("phantomsec rules")


if choice == "A" or choice == "a":
        spam1()
elif choice == "B" or choice == "b":
        spam2()
elif choice == "C" or choice == "c":
        spam3()
elif choice == "D" or choice == "d":
        spam4()
elif choice == "E" or choice == "e":
        Credits()
elif choice == "F" or choice == "f":
        Quit()
else:
        print ("error please choose a valid option")
        menu()
        restart_program()


